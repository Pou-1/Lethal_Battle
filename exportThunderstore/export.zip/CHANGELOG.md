# 1.0.7 Lethal Nuke Mod company compatibility

-   **Added**
-   The nuclear Bomb of lethal Nuke in the scrap spawnable in the battle !

# 1.0.6 Galetry Modded company compatibility

-   **Fix**
-   A bug in the modded company galetry, now you can battle even in this moded company !

# 1.0.5 Modded company compatibility

-   **Fix**
-   A bad condition that now permit the mod to start at company and modded company

# 1.0.4 Make sure only lethal items spawns

-   **Fix**
    -   List of items that spawn at the start
    -   Reduce UI size to not interfere with game object infos

# 1.0.0 Initial release

-   **Added**
    -   Battle to the dead at the end of the game
