# 1.0.0 Initial release

-   **Added**
    -   Battle to the dead at the end of the game

# 1.0.4 Make sure only lethal items spawns

-   **Fix**
    -   List of items that spawn at the start
    -   Reduce UI size to not interfere with game object infos
