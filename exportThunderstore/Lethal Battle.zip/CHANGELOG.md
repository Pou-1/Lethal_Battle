# 1.0.0 Initial release

-   **Added**
    -   Battle to the dead at the end of the game
